# T Gardens website — publication-ready starter

## What's included
- Responsive one-page business website
- Services list and image gallery
- Staffordshire service-area messaging
- Tap-to-call links for 07756 970341 (international format `+447756970341`)
- Mobile navigation and basic SEO metadata

## Publish using Netlify Drop
1. Download and extract `t-gardens-website.zip`.
2. Open https://app.netlify.com/drop and follow the prompts to sign in/create an account if requested.
3. Upload the extracted `t-gardens-website` folder if folder upload is supported. Otherwise, upload the `index.html` file or drag the folder contents into the drop area.
4. Wait for deployment to finish, then open the public URL Netlify gives you.
5. Test the page on your phone. Tap each call button and confirm the phone dialler opens with the correct number.
6. Keep the Netlify URL for now; you can connect a custom domain later.

## Before you share the site
- Check all text, services and photos match the real business.
- Gallery photos are sample externally hosted Unsplash images, not confirmed photos of T Gardens projects.
- Make sure you are happy for the supplied phone number to be publicly displayed.
- Add any missing business details such as hours, exact towns covered, insurance/accreditations if applicable, and social links.
- This is a static site; there is no booking form or analytics yet.
